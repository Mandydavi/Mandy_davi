
import tkinter as tk

def validate_login():
    """验证登录信息"""
    username = username_entry.get()
    password = password_entry.get()
    if username == "admin" and password == "admin123":
        login_success_label.config(text="登录成功！")
    else:
        login_success_label.config(text="用户名或密码错误！")

# 创建主窗口
root = tk.Tk()
root.title("登录界面")

# 创建用户名和密码输入框
username_label = tk.Label(root, text="用户名：")
username_label.grid(row=0, column=0)
username_entry = tk.Entry(root)
username_entry.grid(row=0, column=1)

password_label = tk.Label(root, text="密码：")
password_label.grid(row=1, column=0)
password_entry = tk.Entry(root, show="*")
password_entry.grid(row=1, column=1)

# 创建登录按钮
login_button = tk.Button(root, text="登录", command=validate_login)
login_button.grid(row=2, column=0)

# 创建登录成功标签
login_success_label = tk.Label(root, text="")
login_success_label.grid(row=2, column=1)

# 运行主循环
root.mainloop()
